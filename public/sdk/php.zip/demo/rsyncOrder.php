<?php
/**
 * @Author: Awe
 * @Date:   2019-10-20 11:03:26
 * @Last Modified by:   Awe
 * @Last Modified time: 2019-10-20 11:19:03
 */
date_default_timezone_set('Asia/Shanghai');
header("Content-type: text/html; charset=utf-8");
//异步确认订单的demo 仅供参考 （使用到生成环境请注意）
require_once './config.php';
require_once './Network.php';
//异步回调
class RsyncOrder{
    public function begin(){
		$params = $_POST ;
		/*
		我方的返回数据如下：（请参考 具体的请看 API 接口文档 ）
		{
			"order_sn": "20191020499851555098",
			"merch_order_sn": "2019102050545554",
			"trans_order_sn": "2019102236523586124505",
			"money": "124",
			"real_money": "119.41",
			"complete_date": "2019-10-23 17:13:03",
			"status": "2",
			"channel": "wx",
			"appid": "dZOXY9S0gt8TT0U0",
			"sign": "8b8747a10a613c4f8a3283370dd3ff4a",
			"is_supplement": "0"
		}
		*/
		$sign = $this->getSign();
		//验证签名是否对
		if( $sign != $params['sign'] ){
			exit("sign is error ");
		}
		
		$status = isset($params['status'])  ? $params['status'] : "" ;
		
		//商户一定要做自己的订单重复请求处理
		//有可能我方会发起N次异步回调请求
		if( $status == 2 ){
			//付款成功的业务逻辑
			echo "success";
		} else if( $status == 3  ){
			//付款失败的业务逻辑
			echo "success";
		}  
		//请注意商户这边的业务处理完成之后 ， 要返回一个 success 字符串
		//如果不返回 那么 我方 会发起 5 次 回调的请求
		
    }
    public function getSign(){
        return strtolower( md5(APPID . APPSECRET) );
    }
}

$RsyncOrder = new RsyncOrder();
$order->begin();




