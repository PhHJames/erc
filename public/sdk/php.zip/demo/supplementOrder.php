<?php
/**
 * @Author: Awe
 * @Date:   2019-10-20 11:03:26
 * @Last Modified by:   Awe
 * @Last Modified time: 2019-10-20 11:19:03
 */
date_default_timezone_set('Asia/Shanghai');
header("Content-type: text/html; charset=utf-8");
//补单异步请求的demo 仅供参考 （使用到生成环境请注意）
require_once './config.php';
require_once './Network.php';
//补单异步
class SupplementOrder{
    public function begin(){
		$params = $_POST ;
		/*
		我方的返回数据如下：（请参考 具体的请看 API 接口文档 ）
		{
			"order_sn": "20191020499851555098",
			"merch_order_sn": "2019102050545554",
			"trans_order_sn": "2019102236523586124505",
			"money": "124",
			"real_money": "119.41",
			"complete_date": "2019-10-23 17:13:03",
			"status": "2",
			"channel": "wx",
			"appid": "dZOXY9S0gt8TT0U0",
			"sign": "8b8747a10a613c4f8a3283370dd3ff4a",
			"is_supplement": "1"
		}
		*/
		$sign = $this->getSign();
		//验证签名是否对
		if( $sign != $params['sign'] ){
			exit("sign is error ");
		}
		$is_supplement = isset($params['is_supplement'])  ? $params['is_supplement'] : "" ;
		$status = isset($params['status'])  ? $params['status'] : "" ;
		if($is_supplement == 1  && $status == 2 ){//只有是补单的请求 并且状态是成功的
			//商户自己做业务处理
			//商户也要做好订单去重的处理
			
		}
		echo "success"; //商户要返回一个字符串 success 	
    }
    public function getSign(){
        return strtolower( md5(APPID . APPSECRET) );
    }
}

$SupplementOrder = new SupplementOrder();
$order->begin();




