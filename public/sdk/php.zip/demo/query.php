<?php
/**
 * @Author: Awe
 * @Date:   2019-10-20 11:03:26
 * @Last Modified by:   Awe
 * @Last Modified time: 2019-10-20 11:19:03
 */
date_default_timezone_set('Asia/Shanghai');
header("Content-type: text/html; charset=utf-8");
//查询订单的demo 仅供参考 （使用到生成环境请注意）
require_once './config.php';
require_once './Network.php';
//订单查询
class Order{
    public function query($merch_order_sn){
		$sign = $this->getSign();
        $request = array(
            'appid' => APPID ,
            'sign' => $sign ,
            'merch_order_sn' => $merch_order_sn ,
           
        );
        $url = REQUEST_URI . "/Api_orders/query";
        $resp = Network::RequestData($url , $request);
		
        echo $resp ;
    }
 

    public function getSign(){
        return strtolower( md5(APPID . APPSECRET) );
    }
}

$order = new Order();
$merch_order_sn = "2019102810154571";
$order->query($merch_order_sn);




