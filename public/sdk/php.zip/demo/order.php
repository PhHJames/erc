<?php
/**
 * @Author: Awe
 * @Date:   2019-10-20 11:03:26
 * @Last Modified by:   Awe
 * @Last Modified time: 2019-10-20 11:19:03
 */
date_default_timezone_set('Asia/Shanghai');
header("Content-type: text/html; charset=utf-8");
//下单demo 仅供参考 （使用到生成环境请注意）
require_once './config.php';
require_once './Network.php';
//下单接口
class Order{
    public function place(){
        $merch_order_sn = $this->build_order_no();
        $sign = $this->getSign();
        $channel = "juhe_channel";//请在商户后台，通道管理 里面查看具体开通的哪几个通道 
        $money = rand( 100 , 300 ) ; //支付金额 必须是 元为单位
        $client_ip = Network::GetClientIp();
        $request = array(
            'appid' => APPID ,
            'sign' => $sign ,
            'merch_order_sn' => $merch_order_sn ,
            'channel' => $channel ,
            'money' => $money ,
            'client_ip' => $client_ip 
        );
        $url = REQUEST_URI . "/Api_orders/place";
        $resp = Network::RequestData($url , $request);
		//这个地方根据响应做相关的处理
		//如果 return_type = 1 那么代表了 是跳转去支付
		//如果 return_type = 2 那么代表了扫码去支付
		//具体的请看接口文档 那个是最新的文档
        echo $resp ;
    }
    public  function build_order_no( $len = 16 ){
       $d  = array_map('ord', str_split(substr(uniqid(), 7, 13), 1));
       $a1 = count($d);
       if( ($a1 + 2 ) >$len ){
           return "";
       }
       $a2 = $len - $a1 - 2  ;
       return date('Ymd').substr(implode(NULL, $d ), 0, $a2);
    }

    public function getSign(){
        return strtolower( md5(APPID . APPSECRET) );
    }
}

$order = new Order();
$order->place();




